package br.com.yourLogo.web.interfaces;

import org.openqa.selenium.WebDriver;

public interface AplicacaoWeb {

    WebDriver getdriver();
}
