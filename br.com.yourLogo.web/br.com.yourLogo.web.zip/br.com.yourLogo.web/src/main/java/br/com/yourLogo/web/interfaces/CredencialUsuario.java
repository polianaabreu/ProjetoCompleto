package br.com.yourLogo.web.interfaces;

public interface CredencialUsuario {

    String email ();
    String senha();

}
